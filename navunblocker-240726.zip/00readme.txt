# 20221225 drger; 00readme.txt

MMI3G Navigation Database Unblocker Patch

0. Copy the contents of this directory/folder and subdirectories/subfolders to
   a FAT32 formatted SD card.

1. Start the MMI3G system; wait for all functions to start fully.  The vehicle
   ignition does NOT need to be ON.

2. Insert the write-enabled SD card into an open SD slot and follow the prompts
   on the MMI screen.

3. When the SD script is finished, remove the SD card from the main unit and
   inspect the SD card script plain-text log file for any errors.

4. Restart the MMI system.

5. Confirm that the updated navigation database is not blocked after the MMI
   system is running for at least five (5) minutes.

6. Copy the FSC and acios_db.ini files from the SD card "var" directory/folder
   to a safe place for future reference.
